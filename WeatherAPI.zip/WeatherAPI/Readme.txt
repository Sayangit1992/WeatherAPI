﻿WeatherRepo.cs: Please go to the file WeatherRepo.cs line no : 36 and 
change the path of MapInfo.json as per your system location

MapInfo.json : This file under json folder is holding all cities and latitude, longitude.
If you want you can add more city here.

How to run the program
- please go this path : WeatherAPI\bin\Debug and then double click WeatherAPI.exe

